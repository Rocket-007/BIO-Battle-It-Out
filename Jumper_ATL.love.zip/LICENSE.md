###License
* Copyright (c) 2012 Zeliarden & Roland Yonaba<br/>
  Work released under the terms of the [MIT-License](http://www.opensource.org/licenses/mit-license.php)

###Programming Language 
* [Lua](http://www.lua.org) - [MIT Licensed](http://www.opensource.org/licenses/mit-license.php)

###Framework
* [L�ve2D](http://love2d.org) Framework 
  Copyright (c) 2006-2012 LOVE Development Team, [ZLIB Licensed](https://love2d.org/wiki/License)
    
###Arts & Design
* *map.tmx* - Generated with __Tiled__</br>
   [Tiled Map Editor](http://www.mapeditor.org)<br/>
   Copyright (c) 2008-2012 Thorbj�rn Lindeijer, [GNU GPL Licensed](http://www.gnu.org/licenses/)
  
* Sprites, Assets from [OpenGameArt](http://lpc.opengameart.org/)<br/>
   [Creative Commons 3.0 Attribution CC-BY-SA](http://creativecommons.org/licenses/by-sa/3.0/)